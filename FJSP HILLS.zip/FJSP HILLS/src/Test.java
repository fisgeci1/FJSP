import jdistlib.Exponential;

public class Test {
    public static void main(String[] args) {

        double e = 0.1;

        for (int i = 0; i < 100; i++) {

            System.out.println(Exponential.cumulative(e, 1, false, false));

            e += 0.02;
        }


    }
}
