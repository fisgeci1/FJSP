package Algorithm;

import java.util.ArrayList;

public class Job {

    private ArrayList<Operation> operations;
    private String jobDesc;
    private int count = 0;
    private  int numberOfMachines=0;


    public Job(String jobDesc) {
        operations = new ArrayList<>();
        this.jobDesc = jobDesc;

    }

    public void setNumberOfMachines(int numberOfMachines) {
        this.numberOfMachines = numberOfMachines;
    }

    public int getNumberOfMachines() {
        return numberOfMachines;
    }

    public Operation getOperation(int operationNumber) {
        try {
            for (int a = 0; a< operations.size(); a++) {
                if (operations.get(a).getOperationNumber() == operationNumber) {
                    return operations.get(a);
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public String getJobDesc() {
        return jobDesc;
    }

    public Operation getNext() {
        try {
            Operation operation = operations.get(count);
            count++;
            return operation;
        } catch (Exception e) {
            return null;
        }
    }

    public ArrayList<Operation> getOperations() {
        return operations;
    }

    public void addOperation(Operation operation) {
        operation.setJob(this);
        operations.add(operation);
    }


    public void addAllOperations(ArrayList<Operation> operations) {
        this.operations = operations;
    }

    public void setCount() {
        count--;
    }

}
