package Algorithm;

public class Operation {

    private Job job;
    private int[] flexibleMachines;
    private double processedTime;
    private double[] processingSpeed;
    private int currentMachine;
    private int operationNumber;
    private double startTime;
    private boolean canBeProcessed;

    public Operation(int[] flexibleMachines, double[] processingSpeed, int operationNumber) {
        this.flexibleMachines = new int[flexibleMachines.length];
        this.processingSpeed = new double[processingSpeed.length];
        for (int i = 0; i < flexibleMachines.length; i++) {
            this.flexibleMachines[i] = flexibleMachines[i];
        }
        for (int i = 0; i < processingSpeed.length; i++) {
            this.processingSpeed[i] = processingSpeed[i];
        }
        if (operationNumber == 0) {
            canBeProcessed = true;
        }

        this.operationNumber = operationNumber;
    }


    public Job getJob() {
        return job;
    }

    public double getProcessedTime() {
        return processedTime;
    }

    public int getOperationNumber() {
        return operationNumber;
    }

    public int[] getFlexibleMachines() {
        return flexibleMachines;
    }

    public double getProcessingSpeed(int i) {
        return processingSpeed[i];
    }

    public double[] getProcessingSpeed() {
        return processingSpeed;
    }

    public int getCurrentMachine() {
        return currentMachine;
    }

    public void setProcessedTime(double processedTime) {
        this.processedTime = processedTime;
    }

    public void setCurrentMachine(int currentMachine) {

        int index = 0;
        for (int i : flexibleMachines) {
            if (i == currentMachine) {
                break;
            }
            index++;
        }
        this.currentMachine = currentMachine;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public void setStartTime(double startTime) {
        this.startTime = startTime;
    }

    public void setCanBeProcessed(boolean canBeProcessed) {
        this.canBeProcessed = canBeProcessed;
    }

    public boolean isCanBeProcessed() {
        return canBeProcessed;
    }

    public double getStartTime() {
        return startTime;
    }

    @Override
    public String toString() {

        String machines = "[";
        for (int i : flexibleMachines) {
            machines += i + ",";
        }
        machines += "]";
        return "Operation{" +
                "job=" + job.getJobDesc() +
                ", operationNumber=" + operationNumber +
                ", machine =" + currentMachine +
                ", flexible machines " + machines +
                " start time " + startTime +
                " ,processed time " + processedTime +
                '}';
    }
}
