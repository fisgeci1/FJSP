package Algorithm;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

public class IslandAlgorithm {

    private int numberOfIslands = 10;
    private int migrationMark = 200;
    private Machine[] machines;
    private ArrayList<Job> jobs;
    private int maxGeneration = 5000;
    private  double mutationRate = 0.02;

    public IslandAlgorithm(Machine[] machines, ArrayList<Job> jobs) {

        this.jobs = jobs;
        this.machines = machines;
    }

    public Solution islandAlgorithm() {
        ArrayList<Genetic> islands = new ArrayList<>();


        for (int i = 0; i < numberOfIslands; i++) {
            Genetic island = new Genetic(machines, jobs);
            island.initialize();
            islands.add(island);
        }


        for (int i = 0; i < maxGeneration; i++) {

            if (islands.get(0).getGenerationNumber() % migrationMark == 0) {
                System.out.println("//////////");
                //only the best solution migrates

                Genetic bestIsland = islands.get(0);
                Solution bestSolution = bestIsland.getBest();
                for (Genetic island : islands) {
                    Solution potentialBest = island.getBest();

                    if (potentialBest.getFitness() < bestSolution.getFitness()) {
                        bestIsland = island;
                        bestSolution = potentialBest;
                    }

                }
                for (Genetic island : islands) {
                    if (!island.equals(bestIsland)) {
                        island.addToPopulation(bestSolution);
                    }
                }
                System.out.println("Best " + getFitness(bestSolution.getV2()));
                System.out.println("//////////");
            }

            for (Genetic island : islands) {

                //Lower mutation rate???!!!0.02-0.1
                island.nextGeneration(mutationRate);

            }
        }
        Solution best = islands.get(0).getBest();
        for (Genetic island : islands) {
            if (getFitness(island.getBest().getV2()) < getFitness(best.getV2())) {
                best = island.getBest();
            }
        }
        return best;
    }

    private int checkIfItsASolution(ArrayList<Operation> operations) {
        int contraintsViolatied = 0;
        for (Operation op1 : operations) {
            for (Operation op2 : operations) {
                if (!op1.equals(op2)) {
                    if (op1.getJob().equals(op2.getJob()) && op1.getOperationNumber() < op2.getOperationNumber() && op1.getProcessedTime() > op2.getStartTime()) {
                        contraintsViolatied += 10;
                    }
                }
            }
        }
        return contraintsViolatied;
    }

    public double getFitness(ArrayList<Operation> schedule) {

        double max = 0;
        resetMachine();
        resetSchedule(schedule);
        Queue<Operation> queue = new ArrayDeque<>();
        for (Operation operation : schedule) {
            queue.add(operation);
        }

        while (!queue.isEmpty()) {
            Operation operation = queue.remove();
            if (machines[operation.getCurrentMachine()].process(operation, operation.getJob())) {
            } else {

                queue.add(operation);

            }
        }

        for (Operation operation : schedule) {
            double potentialMax = operation.getProcessedTime();
            if (max < potentialMax) {
                max = potentialMax;
            }
        }
        return max;
    }

    private void resetSchedule(ArrayList<Operation> schedule) {
        for (Operation operation : schedule) {
            operation.setCanBeProcessed(operation.getOperationNumber() == 0);
        }
    }

    private void resetMachine() {
        for (Machine machine : machines) {
            machine.setTotalWorkTime(0);
            machine.resetSchedule();
        }
    }
}
