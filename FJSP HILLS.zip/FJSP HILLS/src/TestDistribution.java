import jdistlib.Gamma;

public class TestDistribution {

    public static void main(String[] args) {
        double e = 0.1;
        for (int i = 0; i < 400; i++) {
            System.out.println(i + ":" + Gamma.density(e, 1.2, 0.78, false));
            e += 0.01;
        }
    }
}
