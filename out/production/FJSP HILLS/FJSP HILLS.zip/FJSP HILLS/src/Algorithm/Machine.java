package Algorithm;

public class Machine {

    private double totalWorkTime;
    private int[] schedule = new int[10000];

    public Machine() {
    }

    public double getTotalWorkTime() {
        return totalWorkTime;
    }

    public void setTotalWorkTime(double totalWorkTime) {
        this.totalWorkTime = totalWorkTime;
    }

    public void process(Operation operation) {
        operation.setStartTime(totalWorkTime);

        totalWorkTime += operation.getProcessingSpeed(operation.getCurrentMachine());

        operation.setProcessedTime(totalWorkTime);
    }


    public boolean process(Operation operation, Job job) {


        if (operation.isCanBeProcessed()) {
            //get current max time of machine
            double currentTime = 0;

            for (Operation operation1 : job.getOperations()) {
                if (currentTime < operation1.getProcessedTime()) {
                    currentTime = operation1.getProcessedTime();
                }
            }

            //we need to get previous the previous operation's processedTime
            if (operation.getOperationNumber() != 0) {
                double jobsPreviousOperationsProcessedTime = operation.getJob().getOperation(operation.getOperationNumber() - 1).getProcessedTime();
                //check if it can add an operation right after the previous one
                for (int i = (int) jobsPreviousOperationsProcessedTime; i < schedule.length; i++) {
//                    System.out.println("Previous " + operation.getJob().getOperations().get(operation.getOperationNumber()-1));
//                    System.out.println("Current " + operation.getJob().getOperations().get(operation.getOperationNumber()));
                    boolean canAdd = true;
                    if (schedule[i] == 0) {
                        for (int j = 1; j < operation.getProcessingSpeed(operation.getCurrentMachine()); j++) {
                            if (schedule[i + j] == 1) {
                                canAdd = false;
                                break;
                            }
                        }
                        if (canAdd) {
                            operation.setStartTime(i);
                            operation.setProcessedTime(i + operation.getProcessingSpeed(operation.getCurrentMachine()));
                            for (int a = i; a < i + operation.getProcessingSpeed(operation.getCurrentMachine()); a++) {
                                schedule[a] = 1;
                            }
                            break;
                        }
                    }
                }
//                System.out.println("SET " + operation.getJob().getOperations().get(operation.getOperationNumber()));

                if (totalWorkTime < operation.getProcessedTime()) {
                    totalWorkTime = operation.getProcessedTime();
                }
            } else {
                //first operations of each job go here
                for (int i = 0; i < schedule.length; i++) {
                    int start = 0;
                    boolean canAdd = true;

                    if (schedule[i] == 0) {

                        for (int j = 0; j < operation.getProcessingSpeed(operation.getCurrentMachine()); j++) {
                            if (schedule[i + j] == 1) {
                                canAdd = false;
                                break;
                            }
                        }
                        if (canAdd) {
                            operation.setStartTime(i);
                            operation.setProcessedTime(i + operation.getProcessingSpeed(operation.getCurrentMachine()));
                            for (int a = i; a < i + operation.getProcessingSpeed(operation.getCurrentMachine()); a++) {
                                schedule[a] = 1;
                            }
                            break;
                        }
                    }
                }
                totalWorkTime = operation.getProcessedTime();
            }
            if (operation.getOperationNumber() != operation.getJob().getOperations().size() - 1) {
//                System.out.println("operation done " + operation + " setting operation " + operation.getJob().getOperation(operation.getOperationNumber()+1).getOperationNumber());
                operation.getJob().getOperation(operation.getOperationNumber() + 1).setCanBeProcessed(true);
            }
            return true;
        }
        return false;

    }

    public double waitTime(double fitness) {
        double wait = 0;
        int[] tempSchedule = new int[(int) fitness];
        for (int i = 0; i < tempSchedule.length; i++) {
            tempSchedule[i] = schedule[i];
        }
        for (int i = 0; i < tempSchedule.length; i++) {
            if (tempSchedule[i] == 0) {
                wait++;

            }
        }
        return wait;
    }

    public void resetSchedule() {
        schedule = new int[10000];
    }
}
