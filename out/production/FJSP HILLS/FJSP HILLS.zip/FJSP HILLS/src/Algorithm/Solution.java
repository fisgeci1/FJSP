package Algorithm;

import java.util.ArrayList;

public class Solution {

    private ArrayList<Operation> v2;
    private ArrayList<Operation> v1;
    private double fitness;
    private double waitTime = 0;
    private double probabilityOfSelection;


    Solution(ArrayList<Operation> v1, ArrayList<Operation> v2) {
        this.v1 = v1;
        this.v2 = v2;
    }

    public void setFitness(double fitness, Machine[] machines) {

        double waitTime = 0;
        for (Machine machine : machines) {
            waitTime += machine.waitTime(fitness);
        }

        this.waitTime = waitTime;

//        this.fitness =  fitness + waitTime*waitTime;
//        this.fitness = Math.pow(fitness, 2) + waitTime * 2;
//        this.fitness = Math.pow(fitness+waitTime,1);
//        this.fitness = fitness*fitness*fitness +waitTime;
//        this.fitness = fitness*fitness + waitTime;
        this.fitness = fitness+waitTime;
    }

    public void setFitness(double fitnes) {

        double waitTime = 0;
//        for (Machine machine : machines) {
//            waitTime += machine.waitTime(fitness);
//        }
//
//        this.waitTime = waitTime;

//        this.fitness =  fitness + waitTime*waitTime;
//        this.fitness = Math.pow(fitness, 2) + waitTime * 2;
//        this.fitness = Math.pow(fitness, 3) + waitTime;
//        this.fitness = Math.pow(fitness, 3)  ;
        this.fitness = fitnes;
    }

    public double getProbabilityOfSelection() {
        return probabilityOfSelection;
    }

    public void setProbabilityOfSelection(double probabilityOfSelection) {
        this.probabilityOfSelection = probabilityOfSelection;
    }

    public double getWaitTime() {
        return waitTime;
    }

    public double getFitness() {
        return fitness;
    }

    public ArrayList<Operation> getV1() {
        return v1;
    }

    public ArrayList<Operation> getV2() {
        return v2;
    }


    private int checkIfItsASolution(ArrayList<Operation> operations) {
        int contraintsViolatied = 0;
        for (Operation op1 : operations) {
            for (Operation op2 : operations) {
                if (!op1.equals(op2)) {
                    if (op1.getJob().equals(op2.getJob()) && op1.getOperationNumber() < op2.getOperationNumber() && op1.getProcessedTime() > op2.getStartTime()) {
                        contraintsViolatied += 50;
                    }
                }
            }
        }
        return contraintsViolatied;
    }
}
