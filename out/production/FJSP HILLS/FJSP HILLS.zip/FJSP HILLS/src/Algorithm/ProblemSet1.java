package Algorithm;

import java.util.ArrayList;

public class ProblemSet1 {


    public ArrayList<Job> getProblemSet() {
        ArrayList<Job> jobs = new ArrayList<>();
        int[] flexibleMachine;
        double[] processingSpeed;
        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 2;
        processingSpeed = new double[6];
        processingSpeed[0] = 5;
        processingSpeed[2] = 4;
        Operation op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 4;
        processingSpeed = new double[6];
        processingSpeed[2] = 5;
        processingSpeed[1] = 1;
        processingSpeed[4] = 3;
        Operation op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 4;
        processingSpeed[5] = 2;
        Operation op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[1] = 6;
        processingSpeed[5] = 5;
        Operation op4 = new Operation(flexibleMachine, processingSpeed, 3);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 2;
        processingSpeed = new double[6];
        processingSpeed[2] = 1;
        Operation op5 = new Operation(flexibleMachine, processingSpeed, 4);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 3;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 6;
        processingSpeed[3] = 3;
        processingSpeed[5] = 6;
        Operation op6 = new Operation(flexibleMachine, processingSpeed, 5);
        Job j1 = new Job("Job 1");

        j1.addOperation(op1);
        j1.addOperation(op2);
        j1.addOperation(op3);
        j1.addOperation(op4);
        j1.addOperation(op5);
        j1.addOperation(op6);


        flexibleMachine = new int[1];
        flexibleMachine[0] = 1;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 2;
        processingSpeed = new double[6];
        processingSpeed[2] = 1;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 0;
        processingSpeed = new double[6];
        processingSpeed[0] = 2;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[3] = 6;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[5] = 5;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        Job j2 = new Job("Job 2");
        j2.addOperation(op1);
        j2.addOperation(op2);
        j2.addOperation(op3);
        j2.addOperation(op4);
        j2.addOperation(op5);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 1;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 4;
        processingSpeed[5] = 2;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[1] = 6;
        processingSpeed[5] = 5;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 4;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[4] = 5;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        Job j3 = new Job("Job 3");

        j3.addOperation(op1);
        j3.addOperation(op2);
        j3.addOperation(op3);
        j3.addOperation(op4);
        j3.addOperation(op5);


        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[1] = 6;
        processingSpeed[5] = 5;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 1;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 2;
        processingSpeed = new double[6];
        processingSpeed[2] = 1;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 4;
        processingSpeed = new double[6];
        processingSpeed[1] = 1;
        processingSpeed[2] = 5;
        processingSpeed[4] = 3;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 4;
        processingSpeed[5] = 2;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        Job j4 = new Job("Job 4");

        j4.addOperation(op1);
        j4.addOperation(op2);
        j4.addOperation(op3);
        j4.addOperation(op4);
        j4.addOperation(op5);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 4;
        processingSpeed = new double[6];
        processingSpeed[1] = 1;
        processingSpeed[2] = 4;
        processingSpeed[4] = 3;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[1] = 6;
        processingSpeed[5] = 5;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 1;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 2;
        processingSpeed = new double[6];
        processingSpeed[0] = 5;
        processingSpeed[2] = 4;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[3] = 6;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op6 = new Operation(flexibleMachine, processingSpeed, 5);

        Job j5 = new Job("Job 5");
        j5.addOperation(op1);
        j5.addOperation(op2);
        j5.addOperation(op3);
        j5.addOperation(op4);
        j5.addOperation(op5);
        j5.addOperation(op6);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 4;
        processingSpeed[5] = 2;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 0;
        processingSpeed = new double[6];
        processingSpeed[0] = 2;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 1;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[1] = 6;
        processingSpeed[5] = 5;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 4;
        processingSpeed = new double[6];
        processingSpeed[0] = 3;
        processingSpeed[4] = 2;
        op6 = new Operation(flexibleMachine, processingSpeed, 5);

        Job j6 = new Job("Job 6");

        j6.addOperation(op1);
        j6.addOperation(op2);
        j6.addOperation(op3);
        j6.addOperation(op4);
        j6.addOperation(op5);
        j6.addOperation(op6);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 5;
        processingSpeed = new double[6];
        processingSpeed[5] = 1;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[0] = 3;
        processingSpeed[3] = 2;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 4;
        processingSpeed = new double[6];
        processingSpeed[0] = 6;
        processingSpeed[1] = 6;
        processingSpeed[4] = 1;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[1];
        flexibleMachine[0] = 2;
        processingSpeed = new double[6];
        processingSpeed[2] = 1;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        Job j7 = new Job("Job 7");
        j7.addOperation(op1);
        j7.addOperation(op2);
        j7.addOperation(op3);
        j7.addOperation(op4);
        j7.addOperation(op5);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 4;
        processingSpeed[5] = 2;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 1;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[1] = 6;
        processingSpeed[5] = 5;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 1;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[3] = 6;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        Job j8 = new Job("Job 8");
        j8.addOperation(op1);
        j8.addOperation(op2);
        j8.addOperation(op3);
        j8.addOperation(op4);
        j8.addOperation(op5);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 5;
        processingSpeed = new double[6];
        processingSpeed[5] = 1;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 4;
        processingSpeed = new double[6];
        processingSpeed[0] = 1;
        processingSpeed[4] = 5;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 3;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 6;
        processingSpeed[3] = 3;
        processingSpeed[5] = 6;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 0;
        processingSpeed = new double[6];
        processingSpeed[0] = 2;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[3] = 6;
        op6 = new Operation(flexibleMachine, processingSpeed, 5);

        Job j9 = new Job("Job 9");

        j9.addOperation(op1);
        j9.addOperation(op2);
        j9.addOperation(op3);
        j9.addOperation(op4);
        j9.addOperation(op5);
        j9.addOperation(op6);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 2;
        flexibleMachine[1] = 5;
        processingSpeed = new double[6];
        processingSpeed[2] = 4;
        processingSpeed[5] = 2;
        op1 = new Operation(flexibleMachine, processingSpeed, 0);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 5;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[2] = 4;
        processingSpeed[5] = 6;
        op2 = new Operation(flexibleMachine, processingSpeed, 1);

        flexibleMachine = new int[3];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 2;
        flexibleMachine[2] = 4;
        processingSpeed = new double[6];
        processingSpeed[1] = 1;
        processingSpeed[2] = 5;
        processingSpeed[4] = 3;
        op3 = new Operation(flexibleMachine, processingSpeed, 2);

        flexibleMachine = new int[1];
        flexibleMachine[0] = 5;
        processingSpeed = new double[6];
        processingSpeed[5] = 1;
        op4 = new Operation(flexibleMachine, processingSpeed, 3);


        flexibleMachine = new int[2];
        flexibleMachine[0] = 1;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[1] = 6;
        processingSpeed[3] = 6;
        op5 = new Operation(flexibleMachine, processingSpeed, 4);

        flexibleMachine = new int[2];
        flexibleMachine[0] = 0;
        flexibleMachine[1] = 3;
        processingSpeed = new double[6];
        processingSpeed[0] = 3;
        processingSpeed[3] = 2;
        op6 = new Operation(flexibleMachine, processingSpeed, 5);
        Job j10 = new Job("Job 10");
        j10.addOperation(op1);
        j10.addOperation(op2);
        j10.addOperation(op3);
        j10.addOperation(op4);
        j10.addOperation(op5);
        j10.addOperation(op6);





        jobs.add(j1);
        jobs.add(j2);
        jobs.add(j3);
        jobs.add(j4);
        jobs.add(j5);
        jobs.add(j6);
        jobs.add(j7);
        jobs.add(j8);
        jobs.add(j9);
        jobs.add(j10);


        return jobs;

    }
}
