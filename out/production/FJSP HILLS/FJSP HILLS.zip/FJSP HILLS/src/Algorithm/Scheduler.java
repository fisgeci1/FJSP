package Algorithm;

import ProblemSets.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;



public class Scheduler {
    static int numberOfMachines = 6;

    public static void main(String[] args) {
        ArrayList<Operation> v1 = new ArrayList<>();
        ArrayList<Operation> v2 = new ArrayList<>();


        ArrayList<Job> jobs = new ArrayList<>();
        Machine m1 = new Machine();
        Machine m2 = new Machine();
        Machine m3 = new Machine();
        Machine m4 = new Machine();
        Machine m5 = new Machine();
        Machine m6 = new Machine();

        Machine[] machines = new Machine[numberOfMachines];

        machines[0] = m1;
        machines[1] = m2;
        machines[2] = m3;
        machines[3] = m4;
        machines[4] = m5;
        machines[5] = m6;


        int[] flexibleMachine = new int[2];

        ArrayList<Job> jobs1 = new ArrayList<>();


//        int max = 6;
//        int min = 3;
//        for (int i = 0; i < 5; i++) {
//
//            Job job = new Job("Job " + i);
//            int operationNumber = ThreadLocalRandom.current().nextInt(min, max + 1);
//            for (int j = 0; j < operationNumber; j++) {
//                int numberOfFlexibleMachines = ThreadLocalRandom.current().nextInt(2, 4);
//                ArrayList<Integer> machineIndexes = new ArrayList<>();
//                ArrayList<Integer> machineSpeeds = new ArrayList<>();
//                for (int k = 0; k < numberOfMachines; k++) {
//                    machineIndexes.add(k);
//                    machineSpeeds.add(k);
//                }
//                flexibleMachine = new int[numberOfFlexibleMachines];
//                processingSpeed = new double[numberOfMachines];
//                for (int a = 0; a < numberOfFlexibleMachines; a++) {
//                    int machine = (int) (Math.random() * machineIndexes.size());
//                    flexibleMachine[a] = machineIndexes.get(machine);
//                    int speed = (int) (Math.random() * machineSpeeds.size());
//                    processingSpeed[machineIndexes.get(machine)] = speed + 1;
//                    machineIndexes.remove(machine);
//                    machineSpeeds.remove(speed);
//                }
//                Operation operation = new Operation(flexibleMachine, processingSpeed, j);
//
//                job.addOperation(operation);
//            }
//            jobs.add(job);
//            jobs1.add(job);
//        }

//

        jobs = new ProblemSetDecoder().getJobs(0);
        jobs1 = new ProblemSetDecoder().getJobs(0);
        machines = new Machine[jobs.get(0).getNumberOfMachines()];
        for (int i = 0; i < machines.length; i++) {
            machines[i] = new Machine();
        }
//
        for (Job job : jobs) {
            for (Operation operation : job.getOperations()) {
                int flexMachine = operation.getFlexibleMachines()[(int) (Math.random() * operation.getFlexibleMachines().length)];
                operation.setCurrentMachine(flexMachine);
                v1.add(operation);
            }
        }
//
//
        jobs1 = reset(jobs1);
//
//
//        Queue<Operation> operations = new ArrayDeque<>();
//
//
//        int reset = 0;
        while (!jobs.isEmpty()) {
            int randomJob = (int) (Math.random() * jobs.size());

            Job job = jobs.get(randomJob);

            Operation operation = job.getNext();
            if (operation != null) {
                v2.add(operation);
            } else {
                jobs.remove(randomJob);
            }


        }

        Queue<Operation> queue = new ArrayDeque<>();
        for (Operation operation : v2) {
            queue.add(operation);
        }
        for (Operation operation : v2) {
            queue.add(operation);
        }

        while (!queue.isEmpty()) {
            Operation operation = queue.remove();
            if (machines[operation.getCurrentMachine()].process(operation, operation.getJob())) {
            } else {

                queue.add(operation);

            }
        }
//
//        HashMap<Integer, String> machineMap = new HashMap<>();
//        for (int i = 0; i < machines.length; i++) {
//            machineMap.put(i, "");
//        }
//        while (!queue.isEmpty()) {
//            Operation operation = queue.remove();
//            if (machines[operation.getCurrentMachine()].process(operation, operation.getJob())) {
//                machineMap.put(operation.getCurrentMachine(), machineMap.get(operation.getCurrentMachine()) + " ->" + operation.getJob().getJobDesc() + " : " + operation.getOperationNumber());
//            } else {
//                queue.add(operation);
//            }
//        }
//        for (int i = 0; i < machineMap.size(); i++) {
//            System.out.println("Machine " + i + " -> " + machineMap.get(i));
//        }
//        System.out.println("is a solution " + checkIfItsASolution(v2));
//        System.out.println(v2.size());
//        Hills hills = new Hills(machines, jobs1);
//


        int I = 2 * ((jobs1.size() - 1) * machines.length);
//        Solution solution = genetic.geneticAlgorithm(0.01, 300);
//        ArrayList<Operation> solution = hills.hills(I, v2, (int) (I * 0.1), I);
//        for (Operation operation : solution) {
//            System.out.println(operation);
//        }
//        System.out.println(solution.size());
//        System.out.println(hills.getFitness(solution) + " is a sulution " + checkIfItsASolution(solution));
        for (int j = 1; j < 2; j++) {
            System.out.println("here");
            jobs = new ProblemSetDecoder().getJobs(j);
            jobs1 = new ProblemSetDecoder().getJobs(j);
            machines = new Machine[jobs.get(0).getNumberOfMachines()];
            for (int i = 0; i < machines.length; i++) {
                machines[i] = new Machine();
            }
            Genetic genetic = new Genetic(machines, jobs);

            IslandAlgorithm islandAlgorithm = new IslandAlgorithm(machines, jobs1);
            try {
//                File myObj = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\Results\\" + "instance" + j + ".txt");
//                String instanceData = "";
//                myObj.createNewFile();
//                FileWriter fileWriter = new FileWriter("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\Results\\" + "instance" + j + ".txt");
//                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                for (int i = 0; i < 50; i++) {
                    Solution solution1 = islandAlgorithm.islandAlgorithm();
//

//                    checkIfItsASolution(solution1.getV2());
//                    instanceData += i + "." + genetic.getFitness(solution1.getV2()) + " generation " + checkIfItsASolution(solution1.getV2()) + "\n";
                    System.out.println( i + "." + genetic.getFitness(solution1.getV2()) + " generation " + checkIfItsASolution(solution1.getV2()));
                }
                System.exit(1);
//                bufferedWriter.write(instanceData);
//                bufferedWriter.close();
            } catch (Exception e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }


        }
    }

    private static boolean checkIfItsASolution(ArrayList<Operation> operations) {
        for (Operation op1 : operations) {
            for (Operation op2 : operations) {
                if (!op1.equals(op2)) {
                    if (op1.getJob().equals(op2.getJob()) && op1.getOperationNumber() < op2.getOperationNumber() && op1.getProcessedTime() > op2.getStartTime()) {
                        System.out.println(op1 + " BOOOO " + op2);

                        System.exit(-1);
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private static ArrayList<Job> reset(ArrayList<Job> jobs) {
        ArrayList<Job> newJobs = new ArrayList<>();
        for (Job job : jobs) {
            Job newJ = new Job(job.getJobDesc());

            for (Operation operation : job.getOperations()) {
                int flexMachine = operation.getFlexibleMachines()[(int) (Math.random() * operation.getFlexibleMachines().length)];
                Operation op = new Operation(operation.getFlexibleMachines(), operation.getProcessingSpeed(), operation.getOperationNumber());
                op.setCurrentMachine(flexMachine);


                newJ.addOperation(op);

            }
            newJobs.add(newJ);
        }
        return newJobs;
    }
}
