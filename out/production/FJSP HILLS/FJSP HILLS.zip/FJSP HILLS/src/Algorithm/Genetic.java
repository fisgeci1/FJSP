package Algorithm;

import jdistlib.Gamma;

import java.util.*;

public class Genetic {

    private final int populationSize;
    private final Machine[] machines;
    private final ArrayList<Job> jobs;
    private final double largest = 0;
    private ArrayList<Solution> population;
    private Solution bestOfGenerations;
    private Solution bestOfAllGenerations;
    private int generationNumber = 1;
    private double crossoverRate = 0.95;


    public Genetic(Machine[] machines, ArrayList<Job> jobs) {
        this.machines = machines;
        this.jobs = jobs;
        System.out.println("Job size " + jobs.size());
        populationSize = 400;
        population = new ArrayList<>();
    }

    private static boolean checkIfItsASolution(ArrayList<Operation> operations, Operation operation) {
        for (Operation op : operations) {
            if (!op.equals(operation)) {
                if (op.getJob().equals(operation.getJob()) && op.getOperationNumber() < operation.getOperationNumber() && op.getProcessedTime() > operation.getStartTime()) {

                    return false;
                }
            }
        }
        return true;
    }

    //fill the populations with random solutions
    private void initialPopulation() {

        for (int i = 0; i < populationSize; i++) {
            resetMachine();
            ArrayList<Job> tempJob = new ArrayList<>();
            for (Job job : jobs) {
                Job newJ = new Job(job.getJobDesc());
                for (Operation operation : job.getOperations()) {
                    Operation op = new Operation(operation.getFlexibleMachines(), operation.getProcessingSpeed(), operation.getOperationNumber());
                    op.setCurrentMachine(operation.getCurrentMachine());
                    op.setJob(newJ);
                    newJ.addOperation(op);
                }
                tempJob.add(newJ);
            }
            ArrayList<Operation> v1 = new ArrayList<>();

            for (Job job : tempJob) {
                for (Operation operation : job.getOperations()) {
                    int randomFlex = (int) (Math.random() * operation.getFlexibleMachines().length);
                    operation.setCurrentMachine(operation.getFlexibleMachines()[randomFlex]);

                    v1.add(operation);
                }
            }


            ArrayList<Operation> v2 = new ArrayList<>();

            while (!tempJob.isEmpty()) {
                int randomJob = (int) (Math.random() * tempJob.size());


                Operation operation = tempJob.get(randomJob).getNext();

                if (operation != null) {
                    v2.add(operation);
                } else {
                    tempJob.remove(randomJob);
                }

            }

            v2 = pertubation(v2, 50);
            getFitness(v2);
            checkIfItsASolution(v2);

            population.add(new Solution(v1, v2));
        }

        bestOfAllGenerations = population.get(0);
//        for (Solution solution : population) {
//            System.out.println(solution.getV2());
//        }
    }

    private ArrayList<Operation> nk(ArrayList<Operation> solution, int function) {
        ArrayList<Operation> tempSolution = createCopy(solution);
        switch (function) {
            case 0:
                tempSolution = n1(tempSolution);
                break;
            case 1:
                tempSolution = n2(tempSolution);
                break;
        }
        return tempSolution;
    }

    private ArrayList<Operation> pertubation(ArrayList<Operation> tempSolution, int maxIter) {

        //s'

        for (int i = 0; i < maxIter; i++) {
            int random = (int) (Math.random() * 2);

            switch (random) {
                case 0:
                    tempSolution = n1(tempSolution);

                    break;
                case 1:
                    tempSolution = n2(tempSolution);
                    break;
            }
        }


        return tempSolution;
    }

    private ArrayList<Operation> n2(ArrayList<Operation> solution) {

        int random = (int) (Math.random() * solution.size());
        Operation randomOperation = solution.get(random);
        int randomFlex = (int) (Math.random() * randomOperation.getFlexibleMachines().length);

        randomOperation.setCurrentMachine(randomOperation.getFlexibleMachines()[randomFlex]);

        solution.add(randomOperation);
        solution.remove(random);
        return solution;
    }

    private ArrayList<Operation> n1(ArrayList<Operation> solution) {

        int randomMachine = (int) (Math.random() * Scheduler.numberOfMachines);

        ArrayList<Operation> operationsInRandomMachine = getOperationsOfMachine(solution, randomMachine);

        for (int i = 1; i < operationsInRandomMachine.size(); i++) {
            int current = findIndexInSolution(operationsInRandomMachine.get(i), solution);
            int preceding = findIndexInSolution(operationsInRandomMachine.get(i - 1), solution);
            Operation tempOp = solution.get(preceding);
            solution.set(preceding, solution.get(current));
            solution.set(current, tempOp);
        }

        return solution;
    }

    private ArrayList<Operation> getOperationsOfMachine(ArrayList<Operation> operations, int m) {
        ArrayList<Operation> ops = new ArrayList<>();
        for (Operation operation : operations) {
            if (operation.getCurrentMachine() == m) {
                ops.add(operation);
            }
        }
        return ops;
    }

    private int findIndexInSolution(Operation operation, ArrayList<Operation> solution) {
        int index = 0;

        for (Operation op : solution) {
            if (op.equals(operation)) {
                break;
            }
            index++;
        }
        if (index == solution.size()) {
            index--;
        }
        return index;

    }

    //pure genetic Algorithm
    public Solution geneticAlgorithm(double mutationRate, int maxGenerations) {
        initialPopulation();

        int notChangin = 0;
        for (int i = 0; i < maxGenerations; i++) {
            evaluate(population);


            population = generateNewGeneration(population, mutationRate);
            if (bestOfAllGenerations == null) {
                bestOfAllGenerations = bestOfGenerations;
            }

            if (bestOfAllGenerations.getFitness() == bestOfGenerations.getFitness()) {
                notChangin++;
            } else {
                if (bestOfAllGenerations.getFitness() < bestOfGenerations.getFitness()) {
                    bestOfAllGenerations = bestOfGenerations;
                }
            }

//            if (notChangin > 10) {
//                break;
//            }

            generationNumber++;
        }


        return bestOfAllGenerations;
    }

    public void initialize() {
        initialPopulation();
    }

    public void nextGeneration(double mutationRate) {


        evaluate(population);


        //order(population)

        Collections.sort(population, new Comparator<Solution>() {
            @Override
            public int compare(Solution lhs, Solution rhs) {
                // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                return lhs.getFitness() > rhs.getFitness() ? 1 : (lhs.getFitness() < rhs.getFitness()) ? -1 : 0;
            }
        });

        //assign  a probability of slection to each individual of the population
        double e = 0;
        double previousFitness = 0.1;
        for (int i = 0; i < populationSize; i++) {
            if (previousFitness != population.get(i).getFitness()) {
                previousFitness = population.get(i).getFitness();
                e += 0.01;
            }
//            population.get(i).setProbabilityOfSelection(Exponential.cumulative(e, 2,false, false));
            population.get(i).setProbabilityOfSelection(Gamma.density(e, 1, 1, false));
//            System.out.println(i + " :" + population.get(i).getFitness() + "  probability = " + population.get(i).getProbabilityOfSelection());
//            System.out.println(i + " :" + getFitness(population.get(i).getV2()) + "  probability = " + population.get(i).getProbabilityOfSelection());
        }
//        if(bestOfGenerations != null)
//            System.out.println( " :" + getFitness(population.get(0).getV2()) + "  probability = " +population.get(0).getProbabilityOfSelection());

        population = generateNewGeneration(population, mutationRate);
        if (getFitness(bestOfAllGenerations.getV2()) > getFitness(bestOfGenerations.getV2())) {
            bestOfAllGenerations = bestOfGenerations;
        }

//            if (notChangin > 10) {
//                break;
//            }

        generationNumber++;
    }

    private ArrayList<Solution> clone(ArrayList<Solution> solutions) {
        ArrayList<Solution> clone = new ArrayList<>();
        for (Solution solution : solutions) {
            clone.add(solution);
        }
        return clone;
    }

    private ArrayList<Solution> generateNewGeneration(ArrayList<Solution> population, double mutationRate) {
        ArrayList<Solution> newPopulation = new ArrayList<>();
        double bestFitness = 0;


        for (int i = 0; i < population.size(); i += 2) {


            //            don't allow  a parent to reproduce with itself
//            while (parntB.equals(parntA)) {
//                population.add(parntB);
//                parntB = pickOne(population);
//            }

            double random = Math.random();
            Solution parntA = pickOne(population);
            Solution parntB = pickOne(population);
            while (!parntA.equals(parntB))
                 parntB = pickOne(population);
            if (random < crossoverRate) {

                Solution child = crossover(parntA, parntB);


                Solution child2 = crossover(parntB, parntA);


                checkIfItsASolution(child2.getV2());


                newPopulation.add(child);
                newPopulation.add(child2);
            } else {
                newPopulation.add(parntB);
                newPopulation.add(parntA);

            }
        }
        mutate(newPopulation, mutationRate);


        evaluate(newPopulation);


        bestFitness = getFitness(newPopulation.get(0).getV2());
        bestOfGenerations = newPopulation.get(0);

        for (int i = 1; i < newPopulation.size(); i++) {
            if (bestFitness > getFitness(newPopulation.get(i).getV2())) {
                bestFitness = getFitness(newPopulation.get(i).getV2());
                bestOfGenerations = newPopulation.get(i);
            }
        }

        return newPopulation;
    }

    private void mutate(ArrayList<Solution> population, double mutationRate) {


        for (Solution solution : population) {
            double random = Math.random();
            int randomOperation = (int) (Math.random() * population.get(0).getV1().size());

            if (random < mutationRate) {

                int randomFlex = (int) (Math.random() * solution.getV1().get(randomOperation).getFlexibleMachines().length);
                solution.getV1().get(randomOperation).setCurrentMachine(solution.getV1().get(randomOperation).getFlexibleMachines()[randomFlex]);
                solution.setFitness(getFitness(solution.getV2()), machines);
//
//                while (!checkIfItsASolution(solution.getV2())) {
////
//                    randomFlex = (int) (Math.random() * solution.getV1().get(randomOperation).getFlexibleMachines().length);
//                    solution.getV1().get(randomOperation).setCurrentMachine(solution.getV1().get(randomOperation).getFlexibleMachines()[randomFlex]);
//                    solution.setFitness(getFitness(solution.getV2()));
//                }


            }
        }

        for (Solution solution : population) {
            double random = Math.random();

            if (random < mutationRate) {
                int i = (int) (Math.random() * solution.getV2().size());
                int j = (int) (Math.random() * solution.getV2().size());

                if (i != j) {
                    Operation temp = solution.getV2().get(i);
                    solution.getV2().set(i, solution.getV2().get(j));
                    solution.getV2().set(j, temp);
                }
//                while (!checkIfItsASolution(solution.getV2())) {
//                    i = (int) (Math.random() * solution.getV2().size());
//                    j = (int) (Math.random() * solution.getV2().size());
//                    temp = solution.getV2().get(i);
//                    solution.getV2().set(i, solution.getV2().get(j));
//                    solution.getV2().set(j, temp);
//                    solution.setFitness(getFitness(solution.getV2()));
//                }


            }
        }

    }

    //Dart Selection method
    private Solution pickOne(ArrayList<Solution> solutions) {
//        int random = (int) (Math.random() * solutions.size());
        double random = (Math.random());

//
//
//        random = (int) (Math.random() * solutions.size());
//        Solution two = solutions.get(random);
//        if (one.getFitness() < two.getFitness()) {
//            solutions.remove(one);
//            return one;
//        }
//        solutions.remove(two);
//        return two;
        int index = (int) (Math.random() * solutions.size());
        while (random > 0) {
//            random -= Math.abs(solutions.get(index).getFitness());
            random -= Math.abs(solutions.get(index).getProbabilityOfSelection());

            index++;
            index %= solutions.size();
        }
        if (index != 0)
            index--;
        Solution solution = solutions.get(index);

        return solution;


    }

    private Solution crossover(Solution parentA, Solution parentB) {

        ArrayList<Operation> childMachineVector = new ArrayList<>(parentA.getV1().size());
        ArrayList<Operation> childOperationVector = new ArrayList<>(parentA.getV1().size());

        for (int i = 0; i < parentA.getV1().size(); i++) {
            double random = Math.random();

            if (random < 0.5) {
                childMachineVector.add(parentA.getV1().get(i));
            } else {
                childMachineVector.add(parentB.getV1().get(i));
            }
        }

        Operation[] subSet1 = new Operation[childMachineVector.size()];

        int random = (int) (Math.random() * parentA.getV2().size());
        Job job = parentA.getV2().get(random).getJob();
        subSet1[random] = parentA.getV2().get(random);
        for (int i = 0; i < parentA.getV2().size(); i++) {
            if (job.equals(parentA.getV2().get(i).getJob()) && !parentA.getV2().get(random).equals(parentA.getV2().get(i))) {
                {
                    double ran = Math.random();
                    if (ran < 0.6) {
                        subSet1[i] = parentA.getV2().get(i);
                    }
                }
            }
        }


        ArrayList<Operation> operations = new ArrayList<>();
        for (int i = 0; i < parentB.getV2().size(); i++) {
            boolean canAdd = true;
            for (Operation op : subSet1) {
                if (op != null) {
                    if ((op.getJob().getJobDesc().equals(parentB.getV2().get(i).getJob().getJobDesc()) && op.getOperationNumber() == parentB.getV2().get(i).getOperationNumber())) {
                        canAdd = false;
                        break;
                    }
                }
            }
            if (canAdd) {
                operations.add(parentB.getV2().get(i));
            }
        }
        int count = 0;
        for (int i = 0; i < subSet1.length; i++) {
            if (subSet1[i] != null) {
                childOperationVector.add(subSet1[i]);
            } else {
                childOperationVector.add(operations.get(count));
                count++;
            }
        }


        Solution child = createCopyOfSolution(childMachineVector, childOperationVector);
        return child;
    }

    private Solution createCopyOfSolution(ArrayList<Operation> childMachineVector, ArrayList<Operation> childOperationVector) {
        Solution child = new Solution(childMachineVector, childOperationVector);
        HashMap<String, Operation> operationMap = new HashMap<>();
        childOperationVector = createCopy(child.getV2());
        for (Operation operation : childOperationVector) {
            operationMap.put(operation.getJob().getJobDesc() + "/" + operation.getOperationNumber(), operation);
        }
        ArrayList<Operation> v1 = new ArrayList<>();
        for (Operation operation : child.getV1()) {
            Operation op = operationMap.get(operation.getJob().getJobDesc() + "/" + operation.getOperationNumber());
            v1.add(op);
        }
        child = new Solution(v1, childOperationVector);
        return child;
    }

    private void evaluate(ArrayList<Solution> population) {
        for (Solution solution : population) {
            solution.setFitness(getFitness(solution.getV2()), machines);
        }

//        normalize(population);
    }

    private void normalize(ArrayList<Solution> population) {
        double max = population.get(0).getFitness();
        double min = max;

        for (int i = 0; i < population.size(); i++) {
            if (max < population.get(i).getFitness()) {
                max = population.get(i).getFitness();
            }
            if (min > population.get(i).getFitness()) {
                min = population.get(i).getFitness();
            }
        }

        for (Solution solution : population) {
            double fitness = 1;
            if (max != min) {
                fitness = (max - solution.getFitness()) / (max - min);
            }
            if (fitness == 0) {
                fitness += 0.0001;

            }
//            System.out.println("min " + min + " max " + max + " current " + solution.getFitness() + " normalized " + fitness);

            solution.setFitness(fitness);
        }
    }

    public double getFitness(ArrayList<Operation> schedule) {

        double max = 0;
        resetMachine();
        resetSchedule(schedule);
        Queue<Operation> queue = new ArrayDeque<>();
        for (Operation operation : schedule) {
            queue.add(operation);
        }

        while (!queue.isEmpty()) {
            Operation operation = queue.remove();
            if (machines[operation.getCurrentMachine()].process(operation, operation.getJob())) {
            } else {

                queue.add(operation);

            }
        }

        for (Operation operation : schedule) {
            double potentialMax = operation.getProcessedTime();
            if (max < potentialMax) {
                max = potentialMax;
            }
        }
        return max;
    }

    private void resetSchedule(ArrayList<Operation> schedule) {
        for (Operation operation : schedule) {
            operation.setCanBeProcessed(operation.getOperationNumber() == 0);
        }
    }

    private void resetMachine() {
        for (Machine machine : machines) {
            machine.setTotalWorkTime(0);
            machine.resetSchedule();
        }
    }

    private ArrayList<Operation> createCopy(ArrayList<Operation> toCopy) {
        ArrayList<Operation> copied = new ArrayList<>();
//        for (Job job : jobs) {
//            Job job1 = new Job(job.getJobDesc());
//            for (Operation operation : job.getOperations()) {
//                for (Operation operation1 : toCopy) {
//                    if (operation.getJob().getJobDesc().equals(operation1.getJob().getJobDesc()) && operation.getOperationNumber() == operation1.getOperationNumber()) {
//                        Operation op = new Operation(operation1.getFlexibleMachines(), operation1.getProcessingSpeed(), operation1.getOperationNumber());
//                        op.setJob(job1);
//                        op.setCurrentMachine(operation1.getCurrentMachine());
//                        job1.addOperation(op);
//                        copied.add(op);
//                        break;
//                    }
//                }
//            }
//        }
        copied = new ArrayList<>();
        HashMap<String, Job> jobMap = new HashMap<>();
        for (Job job : jobs) {
            jobMap.put(job.getJobDesc(), new Job(job.getJobDesc()));
        }
        for (Operation operation : toCopy) {
            Operation op = new Operation(operation.getFlexibleMachines(), operation.getProcessingSpeed(), operation.getOperationNumber());
            op.setJob(jobMap.get(operation.getJob().getJobDesc()));
            op.setCurrentMachine(operation.getCurrentMachine());
            jobMap.get(op.getJob().getJobDesc()).addOperation(op);
            copied.add(op);
        }

        return copied;
    }

    private boolean checkIfItsASolution(ArrayList<Operation> operations) {
        for (Operation op1 : operations) {
            for (Operation op2 : operations) {
                if (!op1.equals(op2)) {
                    if (op1.getJob().equals(op2.getJob()) && op1.getOperationNumber() < op2.getOperationNumber() && op1.getProcessedTime() > op2.getStartTime()) {

                        System.out.println(op1 + " BOOOO " + op2);

                        System.exit(-1);
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public int getGenerationNumber() {
        return generationNumber;
    }

    public void addToPopulation(Solution solution) {
        population.add(solution);
        if (getFitness(bestOfAllGenerations.getV2()) > getFitness(solution.getV2())) {
            bestOfAllGenerations = solution;
        }
    }

    public Solution getBest() {
        return bestOfAllGenerations;
    }

    public Solution getBestOfGeneration() {
        return bestOfGenerations;
    }
}
