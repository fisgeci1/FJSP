package Algorithm;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Queue;

public class Hills {
    private Machine[] machines = new Machine[Scheduler.numberOfMachines];
    private ArrayList<Job> jobs;

    public Hills(Machine[] machines, ArrayList<Job> jobs) {
        this.machines = machines;
        this.jobs = jobs;
    }


    public ArrayList<Operation> hills(int ils, ArrayList<Operation> initialSolution, int kmax, int sMax) {

        System.out.println(initialSolution + "is a solution " + checkIfItsASolution(initialSolution));
        ArrayList<Operation> tempSolution = createCopy(initialSolution);
        double tempFitness = getFitness(tempSolution);
        System.out.println(tempFitness);
        double currentFitness = getFitness(initialSolution);

        tempSolution = localSearch(tempSolution);

        tempFitness = getFitness(tempSolution);
        for (int i = 0; i < ils; i++) {

            tempSolution = pertubation(tempSolution, kmax);

            tempSolution = simulatedAnnealing(100, 0.001, 0.998, sMax, tempSolution);

            tempFitness = getFitness(tempSolution);


            System.out.println("Temp Solution " + tempFitness + " is a solution " + checkIfItsASolution(tempSolution));

            if (tempFitness < currentFitness) {

                initialSolution = createCopy(tempSolution);
                currentFitness = getFitness(initialSolution);
                System.out.println(currentFitness);

            } else {
                tempSolution = createCopy(initialSolution);
                tempFitness = getFitness(tempSolution);
            }
        }
        return initialSolution;
    }


    private ArrayList<Operation> simulatedAnnealing(double temperature, double finalTemperature, double coolingRate, int maxIteration, ArrayList<Operation> solution) {

        double initialFitness = getFitness(solution);

        //s*
        ArrayList<Operation> betterSolution = createCopy(solution);
        double betterSolutionFitness = getFitness(betterSolution);


        //s'
        ArrayList<Operation> tempSolution = createCopy(solution);
        double tempSolutionFitness = getFitness(tempSolution);


        while (temperature > finalTemperature) {
            for (int i = 0; i < maxIteration; i++) {
                int random = (int) (Math.random() * 3);
                tempSolution = nk(tempSolution, random);
                tempSolutionFitness = getFitness(tempSolution);
                if (tempSolutionFitness < initialFitness) {
                    solution = createCopy(tempSolution);
                    initialFitness = getFitness(solution);
                    if (tempSolutionFitness < betterSolutionFitness) {
                        betterSolution = createCopy(tempSolution);
                        betterSolutionFitness = getFitness(betterSolution);

                        tempSolution = localSearch(tempSolution);

                        tempSolutionFitness = getFitness(tempSolution);

                        if (tempSolutionFitness < betterSolutionFitness) {
                            betterSolution = createCopy(tempSolution);
                            betterSolutionFitness = getFitness(betterSolution);
                        }

                    }
                } else {
                    double exponent = (-(tempSolutionFitness - initialFitness)) / temperature;
                    double probability = Math.exp(exponent);
                    if (probability > 0.6) {
                        solution = createCopy(tempSolution);
                        initialFitness = getFitness(solution);
                    }
                }
            }
            temperature *= coolingRate;
        }
        return betterSolution;
    }

    private ArrayList<Operation> pertubation(ArrayList<Operation> solution, int maxIter) {

        //s'
        ArrayList<Operation> tempSolution = createCopy(solution);

        for (int i = 0; i < maxIter; i++) {
            int random = (int) (Math.random() * 3);
            tempSolution = nk(tempSolution, random);
        }


        return tempSolution;
    }

    private ArrayList<Operation> nk(ArrayList<Operation> solution, int function) {
        ArrayList<Operation> tempSolution = createCopy(solution);
        switch (function) {
            case 0:
                tempSolution = n1(tempSolution);
                break;
            case 1:
                tempSolution = n2(tempSolution);
                break;
            case 2:
                tempSolution = n3(tempSolution);
                break;

        }
        return tempSolution;
    }

    private ArrayList<Operation> n1(ArrayList<Operation> solution) {

        int randomMachine = (int) (Math.random() * Scheduler.numberOfMachines);

        ArrayList<Operation> operationsInRandomMachine = getOperationsOfMachine(solution, randomMachine);

        for (int i = 1; i < operationsInRandomMachine.size(); i++) {
            int current = findIndexInSolution(operationsInRandomMachine.get(i), solution);
            int preceding = findIndexInSolution(operationsInRandomMachine.get(i - 1), solution);
            Operation tempOp = solution.get(preceding);
            solution.set(preceding, solution.get(current));
            solution.set(current, tempOp);
        }

        return solution;
    }

    private ArrayList<Operation> n2(ArrayList<Operation> solution) {

        int random = (int) (Math.random() * solution.size());
        Operation randomOperation = solution.get(random);
        int randomFlex = (int) (Math.random() * randomOperation.getFlexibleMachines().length);

        randomOperation.setCurrentMachine(randomOperation.getFlexibleMachines()[randomFlex]);

        solution.add(randomOperation);
        solution.remove(random);
        return solution;
    }

    private ArrayList<Operation> n3(ArrayList<Operation> solution) {

        int random = (int) (Math.random() * solution.size());
        Operation randomOperation = solution.get(random);

        if (random > 0) {
            if (!solution.get(random - 1).getJob().equals(randomOperation.getJob())) {
                solution.set(random, solution.get(random - 1));
                solution.set(random - 1, randomOperation);
            }
        }
        return solution;
    }


    private int findIndexInSolution(Operation operation, ArrayList<Operation> solution) {
        int index = 0;

        for (Operation op : solution) {
            if (op.getJob().getJobDesc().equals(operation.getJob().getJobDesc()) && op.getOperationNumber() == operation.getOperationNumber()) {
                break;
            }
            index++;
        }
        if (index == solution.size()) {
            index--;
        }
        return index;

    }


    private ArrayList<Operation> localSearch(ArrayList<Operation> initial) {
        //s*
        ArrayList<Operation> betterSolution = createCopy(initial);
        double betterSolutionFitness = getFitness(betterSolution);

        double initialSolutionFitness = getFitness(initial);
        //s'
        ArrayList<Operation> tempSolution = createCopy(initial);
        double tempSolutionFitness = getFitness(tempSolution);


        //part A exchange operations in the machines
        for (int m = 0; m < Scheduler.numberOfMachines; m++) {
            ArrayList<Operation> operations = getOperationsOfMachine(tempSolution, m);

            for (int i = 1; i < operations.size(); i++) {
                operations = getOperationsOfMachine(tempSolution, m);

                int current = findIndexInSolution(operations.get(i), tempSolution);
                int preceding = findIndexInSolution(operations.get(i - 1), tempSolution);
                Operation tempOp = tempSolution.get(preceding);
                tempSolution.set(preceding, tempSolution.get(current));
                tempSolution.set(current, tempOp);
                tempSolutionFitness = getFitness(tempSolution);

                if (tempSolutionFitness < betterSolutionFitness) {
                    betterSolution = createCopy(tempSolution);

                    betterSolutionFitness = getFitness(betterSolution);
                }
                tempSolution = createCopy(initial);
                tempSolutionFitness = getFitness(tempSolution);
            }
        }

        int count = 0;
        //Part b
        for (int i = 0; count < tempSolution.size(); i++) {
            if (tempSolution.get(i).getFlexibleMachines().length == 1) continue;
            int randomMachine = (int) (Math.random() * tempSolution.get(i).getFlexibleMachines().length);
            tempSolution.get(i).setCurrentMachine(tempSolution.get(i).getFlexibleMachines()[randomMachine]);
            tempSolution.add(tempSolution.get(i));
            tempSolution.remove(i);
            i--;
            tempSolutionFitness = getFitness(tempSolution);

            if (tempSolutionFitness < betterSolutionFitness) {
                betterSolution = createCopy(tempSolution);
                betterSolutionFitness = getFitness(betterSolution);
                initial = createCopy(tempSolution);
            }
            count++;
        }


        return betterSolution;
    }


    private ArrayList<Operation> getOperationsOfMachine(ArrayList<Operation> operations, int m) {
        ArrayList<Operation> ops = new ArrayList<>();
        for (Operation operation : operations) {
            if (operation.getCurrentMachine() == m) {
                ops.add(operation);
            }
        }
        return ops;
    }

    private ArrayList<Operation> createCopy(ArrayList<Operation> toCopy) {
        ArrayList<Operation> copied = new ArrayList<>();
        HashMap<String, Job> jobMap = new HashMap<>();
        for (Job job : jobs) {
            jobMap.put(job.getJobDesc(), new Job(job.getJobDesc()));
        }
        int i = 0;
        for (Operation operation : toCopy) {
            Operation op = new Operation(operation.getFlexibleMachines(), operation.getProcessingSpeed(), operation.getOperationNumber());
            op.setCurrentMachine(operation.getCurrentMachine());
            op.setJob(jobMap.get(operation.getJob().getJobDesc()));
            jobMap.get(op.getJob().getJobDesc()).addOperation(op);
            copied.add(op);
        }

        return copied;
    }


    public double getFitness(ArrayList<Operation> schedule) {
        double max = 0;
        resetMachine();
        resetSchedule(schedule);

        Queue<Operation> queue = new ArrayDeque<>();
        for (Operation operation : schedule) {
            queue.add(operation);
        }

        while (!queue.isEmpty()) {
            Operation operation = queue.remove();
            if (machines[operation.getCurrentMachine()].process(operation, operation.getJob())) {
            } else {
                queue.add(operation);
            }
        }
        for (Operation operation : schedule) {
            if (max < operation.getProcessedTime()) {
                max = operation.getProcessedTime();
            }
        }
        return max;
    }

    private void resetSchedule(ArrayList<Operation> schedule) {
        for (Operation operation : schedule) {
            if (operation.getOperationNumber() != 0) {
                operation.setCanBeProcessed(false);
            } else {
                operation.setCanBeProcessed(true);
            }
        }
    }

    private boolean checkIfItsASolution(ArrayList<Operation> operations) {
        for (Operation op1 : operations) {
            for (Operation op2 : operations) {
                if (!op1.equals(op2)) {
                    if (op1.getJob().equals(op2.getJob()) && op1.getOperationNumber() < op2.getOperationNumber() && op1.getProcessedTime() > op2.getStartTime()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private void resetMachine() {
        for (Machine machine : machines) {
            machine.setTotalWorkTime(0);
            machine.resetSchedule();
        }
    }
}
