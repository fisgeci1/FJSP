package ProblemSets;

import Algorithm.Job;
import Algorithm.Operation;

import java.io.*;
import java.util.ArrayList;

public class ProblemSetDecoder {


    public ArrayList<Job> getJobs(int instance) {
        ArrayList<Job> jobs = new ArrayList<>();
        File file = null;
//        switch (instance) {
//            case 1:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la01.fjs");
//                break;
//            case 2:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la02.fjs");
//                break;
//            case 3:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la03.fjs");
//                break;
//            case 4:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la04.fjs");
//                break;
//            case 5:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la05.fjs");
//                break;
//            case 6:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la06.fjs");
//                break;
//            case 7:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la07.fjs");
//
//                break;
//            case 8:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la08.fjs");
//
//                break;
//            case 9:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la09.fjs");
//
//                break;
//            case 10:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la10.fjs");
//
//                break;
//            case 11:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la11.fjs");
//
//                break;
//            case 12:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la12.fjs");
//                break;
//            case 13:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la13.fjs");
//                break;
//            case 14:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la14.fjs");
//                break;
//            case 15:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la15.fjs");
//                break;
//            case 16:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la16.fjs");
//                break;
//            case 17:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la17.fjs");
//                break;
//            case 18:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la18.fjs");
//                break;
//            case 19:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la19.fjs");
//                break;
//            case 20:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la20.fjs");
//                break;
//            case 21:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la21.fjs");
//
//                break;
//            case 22:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la22.fjs");
//
//                break;
//            case 23:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la23.fjs");
//
//                break;
//            case 24:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la24.fjs");
//
//                break;
//            case 25:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la25.fjs");
//
//                break;
//            case 26:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la26.fjs");
//                break;
//            case 27:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la27.fjs");
//
//                break;
//            case 28:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la28.fjs");
//
//                break;
//            case 29:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la29.fjs");
//                break;
//            default:
//                file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Hunrik\\edata\\la30.fjs");
//
//                break;
//        }

        file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Bradimarte\\Mk01.fjs");
//        file = new File("C:\\Users\\fis20\\IdeaProjects\\FJSP HILLS\\src\\ProblemSets\\Barnes\\mt10xyz.fjs");

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String st = "";
            String problem = "";
            while ((st = br.readLine()) != null) {
                problem += st.trim() + "\n";
            }

            String[] seperatedLines = problem.split("\\n");


            int[] flexibleMachines = new int[5];
            double[] processingSpeed = new double[Integer.parseInt(seperatedLines[0].split("\\s")[1])];
            int numberOfMachines = Integer.parseInt(seperatedLines[0].split("\\s")[1]);

            for (int i = 1; i < seperatedLines.length; i++) {
                String jobString = seperatedLines[i];

                String[] operationsInfo = jobString.trim().split("[\\s]");

                Job job = new Job("Job " + i);
                int operationNumber = 0;
                for (int j = 1; j < operationsInfo.length; j++) {
                    int numberOfMachineForOperation = Integer.parseInt(operationsInfo[j]);
                    flexibleMachines = new int[numberOfMachineForOperation];
                    processingSpeed = new double[processingSpeed.length];
                    int count = 0;
                    for (int k = j + 1; count < numberOfMachineForOperation; k += 2) {

                        int machine = Integer.parseInt(operationsInfo[k]) - 1;
                        double speed = Integer.parseInt(operationsInfo[k + 1]);

                        flexibleMachines[count] = machine;
                        processingSpeed[machine] = speed;

                        count++;
                        j += 2;
                    }
                    Operation operation = new Operation(flexibleMachines, processingSpeed, operationNumber);
                    operationNumber++;
                    job.addOperation(operation);
                    job.setNumberOfMachines(numberOfMachines);
                }

                jobs.add(job);

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jobs;
    }
}
